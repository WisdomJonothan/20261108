#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
confirm=$3
export PYTHONPATH="$work:$confirm/admission-study:$confirm:$stage:scripts"
p=.venv/bin/python
data=data/track1_tempo
reference="$stage/evidence-consensus-head-replay-holdout.json"
until [ "$(find "$work" -maxdepth 1 -name 'deep-0p6b-held-p?.json' -size +0c | wc -l)" = 4 ]; do sleep 5; done
"$p" -m retrieve_union_with_pointwise_scan pools --manifest "$work/deep-0p6b-held-manifest.json" --reference "$reference" --scores "$work"/deep-0p6b-held-p?.json --output "$work/deep-pointwise-held-pools.json"
"$p" -m retrieve_union_with_reasoning_encoder audit --pools "$work/deep-pointwise-held-pools.json" --data-root "$data" --output "$work/deep-pointwise-held-audit.json"
"$p" -m replay_feedback_admission prepare --manifest "$stage/wide-train.json" --pools "$work/deep-pointwise-held-pools.json" --output "$work/deep-pointwise-offers.json"
"$p" - "$work/deep-pointwise-offers.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1])
rows=json.loads(p.read_text())['queries']
for i in range(2):
    with p.with_stem(p.stem+f'-p{i}').open('x') as out:
        json.dump({'queries':rows[i::2]},out,separators=(',',':'))
PY
jobs=()
for i in 0 1; do
    quote=$((i+2))
    for gpu in "$i" "$quote"; do
        until [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 5; done
    done
    CUDA_VISIBLE_DEVICES=$quote PYTHONPATH="$stage:scripts" "$p" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$work/deep-pointwise-offers-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$work/deep-heldquote-p$i" --output "$work/deep-heldquote-p$i.json" > "$work/deep-heldquote-p$i.log" 2>&1 &
    jobs+=($!)
    CUDA_VISIBLE_DEVICES=$i "$p" -u "$work/score_specialist_shortlists.py" --manifest "$work/deep-pointwise-offers.json" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --shards 2 --shard-index "$i" --checkpoint "$work/deep-held8b-p$i" --output "$work/deep-held8b-p$i.json" > "$work/deep-held8b-p$i.log" 2>&1 &
    jobs+=($!)
done
for pid in "${jobs[@]}"; do wait "$pid"; done
"$p" -m replay_feedback_admission narrow --grade-all-offers --manifest "$work/deep-pointwise-offers.json" --pointwise "$work"/deep-held8b-p?.json --output "$work/deep-held-full-offers.json"
"$p" -m replay_feedback_admission evaluate --manifest "$work/deep-held-full-offers.json" --reference "$reference" --data-root "$data" --old-pointwise "$stage"/pretrained-held-p?.json "$stage"/pretrained-extra-p?.json --new-pointwise "$work"/deep-held8b-p?.json --old-evidence "$stage"/evidence-reasoner-held-p?.json --new-evidence "$work"/deep-heldquote-p?.json --output "$work/deep-held-admission.json"
