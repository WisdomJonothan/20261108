"""Attribute each reachable one-admission improvement to its first missed gate."""
import argparse
from collections import Counter
import json
from pathlib import Path

from coverage_cf_bound import read_qrels
from eval_qwen_reranker_adapter import candidate_judges
from replay_anchor_fallback import index
from replay_feedback_admission import merge_proposal_grades
from replay_passage_admission import observations


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('pools', 'manifest', 'admission', 'data-root', 'output'):
        p.add_argument(f'--{name}', required=True, type=Path)
    for name in ('old-evidence', 'new-evidence', 'old-pointwise', 'new-pointwise'):
        p.add_argument(f'--{name}', required=True, type=Path, nargs='+')
    a = p.parse_args()
    pools = index(json.loads(a.pools.read_text()))
    manifests = index({'per_query': json.loads(a.manifest.read_text())['queries']})
    results = index(json.loads(a.admission.read_text()))
    old, new = observations(a.old_evidence), merge_proposal_grades(a.new_evidence)
    old_scores, new_scores = (candidate_judges(paths)[0]['pretrained']
                             for paths in (a.old_pointwise, a.new_pointwise))
    qs = {d: read_qrels(a.data_root/d/'qrels_train.txt') for d, _ in pools}
    sources = tuple(next(iter(pools.values()))['offers'])
    summary = {source: Counter() for source in sources}
    cases = []
    for key, row in pools.items():
        gold = qs[key[0]][key[1]]
        prior = row['prior_ten']
        ordinals = {doc: old[key][doc]['reasoned' if old[key][doc]['verified'] else 'direct']
                    for doc in prior[2:] if doc not in gold and doc in old[key]}
        entries = {}
        for source in sources:
            offers = set(row['offers'][source]) & gold
            checked = set(manifests[key]['proposals'][source]) & offers
            # Work on beneficial same-position exchanges under binary relevance.
            pairs = [(left, right) for left in ordinals for right in checked]
            proof = [(left, right) for left, right in pairs if new[key][right]['verified']]
            support = [(left, right) for left, right in proof if new[key][right]['reasoned'] >= 2]
            margin = [(left, right) for left, right in support if new[key][right]['reasoned']-ordinals[left] >= .5]
            eligible = [(left, right) for left, right in margin
                        if new_scores[key]['scores'][right] > old_scores[key]['scores'][left]]
            delta = results[key]['scores'][source] - results[key]['scores']['current']
            considered = {
                'reachable': bool(offers and ordinals), 'proposed': bool(pairs),
                'has_verified_quote': bool(proof), 'grade_at_least_two': bool(support),
                'beats_incumbent_by_half': bool(margin), 'beats_incumbent_pointwise': bool(eligible),
                'improved': delta > 0, 'declined': delta < 0,
            }
            if delta > 0 and not eligible:
                raise ValueError(f'An observed improvement mismatches the policy in {key}')
            summary[source].update({stage: int(flag) for stage, flag in considered.items()})
            entries[source] = considered
        cases.append({'domain': key[0], 'qid': key[1], 'stages': entries})
    with a.output.open('x', encoding='utf8') as out:
        json.dump({'summary': summary, 'per_query': cases}, out, separators=(',', ':'))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
