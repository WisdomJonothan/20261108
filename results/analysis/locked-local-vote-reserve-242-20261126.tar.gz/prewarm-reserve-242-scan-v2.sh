#!/usr/bin/env bash
set -euo pipefail
work=$1
panel="$work/transfer-reserve-242"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
p=.venv/bin/python
export PYTHONPATH="$work:scripts"
until [ -s "$panel/old-pointwise-p0.json" ] && [ -s "$panel/old-pointwise-p1.json" ]; do sleep 5; done
"$p" - "$panel/locked-local-vote/large-scan.json" "$panel/warm-scan-history-input.json" <<'PY'
from pathlib import Path
import json,sys
source,target=map(Path,sys.argv[1:])
rows=[r for r in json.loads(source.read_text())['queries'] if r['domain']=='history']
assert len(rows)==112
with target.open('x') as out: json.dump({'queries':rows},out,separators=(',',':'))
PY
while :; do
    for gpu in 2 3; do
        if [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then
            CUDA_VISIBLE_DEVICES=$gpu "$p" -u "$work/score_specialist_shortlists.py" --manifest "$panel/warm-scan-history-input.json" --data-root data/track1_tempo --model /dev/shm/reteco-yuanbao-0101299 --model-revision 0101299a7937a016848d8d55b092f6e31cfa312d --evidence-mode dispersed --clip-dispersed-outliers --batch-size 32 --checkpoint "$panel/warm-scan-history" --output "$panel/warm-scan-history.json"
            exit 0
        fi
    done
    sleep 5
done
