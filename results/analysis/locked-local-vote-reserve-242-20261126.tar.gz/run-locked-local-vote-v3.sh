#!/usr/bin/env bash
set -euo pipefail
mode=$1
work=$2
stage=$3
study=$4
retrieval=$5
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
py=.venv/bin/python
data=data/track1_tempo
panel="$work/transfer-reserve-242"
lock="$work/separated-gain-local-scale-lock.json"
model8=/dev/shm/reteco-qwen3-reranker-8b-77d193c
pin8=77d193c791ed757ca307ee72715aa132723da912
model6=/dev/shm/reteco-yuanbao-0101299
pin6=0101299a7937a016848d8d55b092f6e31cfa312d
test "$(sha256sum "$panel/reserve-ids.json" | cut -d' ' -f1)" = be632c5f62f51d8c7edc123c3354157c7421c174c8ea58dbe7c47c6c35757807
test "$(sha256sum "$work/separated-gain-training-result.json" | cut -d' ' -f1)" = 5e34f05ed461be089416a8a085d9aa88d3cbff25738f1c17c37da3c6886ac88a
"$py" - "$lock" "$panel/reserve-ids.json" "$work/separated-gain-training-result.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
lock, ids, prior=map(Path,sys.argv[1:])
r=json.loads(prior.read_text())
expected=json.loads(ids.read_text())
assert not {tuple(k) for k in r['fit_ids']}.intersection(map(tuple,expected['queries']))
candidate=r['fixed']['local_candidate_scale']
assert candidate['change']['point']>0 and candidate['minimum_leave_one_domain_out']>0
from collections import defaultdict
from statistics import mean
def change(rows):
    domains=defaultdict(list)
    for x in rows: domains[x['domain']].append(x['scores']['local_candidate_scale']-x['scores']['current'])
    return mean(map(mean,domains.values()))
panels={x['panel'] for x in r['per_query']}
effects={name:change([x for x in r['per_query'] if x['panel']!=name]) for name in sorted(panels)}
assert min(effects.values())>0
record={'selected':'local_candidate_scale','source_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),
        'development':candidate,'omit_panels':effects}
if lock.exists():
    assert json.loads(lock.read_text())==record
else:
    with lock.open('x') as handle: json.dump(record,handle,separators=(',',':'))
PY
flags=()
if [ "$mode" = reserve ]; then
    dest="$panel/locked-local-vote"
    manifest="$panel/wide60.json"
    head="$panel/head.json"
    consensus="$panel/consensus.json"
    anchor=("$panel"/old-pointwise-p?.json)
    proof_glob="$panel"
    flags=(--confirmation --reserve-ids "$panel/reserve-ids.json")
    bge="$retrieval/bge-train"
elif [ "$mode" = dev ]; then
    "$py" - "$panel/locked-local-vote/result.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]))
assert r['reserved_ids'] and len(r['per_query'])==242 and r['selected']=='local_candidate_scale'
assert r['confirmation']['selected']['change']['point']>0 and r['selected_minimum_leave_one_domain_out']>0
print('The fixed local-scale rule passed its independent confirmation gates',flush=True)
PY
    dest="$work/locked-local-official"
    manifest="$stage/wide-dev.json"
    head="$stage/evidence-consensus-head-replay-dev.json"
    consensus="$stage/evidence-consensus-extension-audited-dev.json"
    anchor=("$stage"/reasoner-dev-8b-p?.json)
    proof_glob="$stage"
    bge="$retrieval/bge-dev"
else
    exit 2
fi
mkdir -p "$dest"
score_all() {
    local manifest=$1 prefix=$2 model=$3 pin=$4 batch=$5
    local i gpu pid
    local -a free jobs
    while :; do
        free=()
        for i in 0 1 2 3; do
            if [ "$(nvidia-smi -i "$i" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then free+=("$i"); fi
        done
        if [ "${#free[@]}" -ge 2 ]; then break; fi
        sleep 8
    done
    echo "Launching $prefix on GPUs ${free[*]}"
    jobs=()
    if [ "$mode" = reserve ] && [ "$prefix" = "$dest/scan" ] && [ -s "$panel/warm-scan-history/history.json" ]; then
        for i in "${!free[@]}"; do
            mkdir -p "$prefix-p$i"
            ln "$panel/warm-scan-history/history.json" "$prefix-p$i/history.json"
        done
    fi
    for i in "${!free[@]}"; do
        gpu=${free[i]}
        CUDA_VISIBLE_DEVICES=$gpu "$py" -u "$work/score_specialist_shortlists.py" --manifest "$manifest" --data-root "$data" --model "$model" --model-revision "$pin" --evidence-mode dispersed --clip-dispersed-outliers --batch-size "$batch" --shards "${#free[@]}" --shard-index "$i" --checkpoint "$prefix-p$i" --output "$prefix-p$i.json" > "$prefix-p$i.log" 2>&1 &
        jobs+=($!)
    done
    for pid in "${jobs[@]}"; do wait "$pid"; done
}
if [ ! -s "$dest/large-scan.json" ]; then
    "$py" -m retrieve_union_with_pointwise_scan prepare --manifest "$manifest" --mxbai runs --bge "$bge" --output "$dest/large-scan.json"
fi
if [ "$mode" = reserve ]; then
    while [ ! -s "$head" ]; do sleep 10; done
    if [ -s "$panel/warm-scan-history.pid" ]; then
        warm=$(cat "$panel/warm-scan-history.pid")
        while kill -0 "$warm" 2>/dev/null && [ ! -s "$panel/warm-scan-history/history.json" ]; do sleep 5; done
    fi
    anchor=("$panel"/old-pointwise-p?.json)
    evidence=("$proof_glob"/proof-p?.json)
else
    evidence=("$proof_glob"/evidence-reasoner-dev-p?.json)
fi
score_all "$dest/large-scan.json" "$dest/scan" "$model6" "$pin6" 32
"$py" -m replay_wide_pointwise_vote prepare --manifest "$dest/large-scan.json" --reference "$head" --initial-scan "$dest"/scan-p?.json --pointwise "${anchor[@]}" --output "$dest/scopes.json" --missing-manifest "$dest/missing.json" --only-vote-documents
score_all "$dest/missing.json" "$dest/pointwise" "$model8" "$pin8" 6
"$py" -m replay_wide_pointwise_vote evaluate --retain-position-prior --local-only --manifest "$dest/scopes.json" --reference "$head" --consensus "$consensus" --data-root "$data" --pointwise "${anchor[@]}" "$dest"/pointwise-p?.json --evidence "${evidence[@]}" --selection "$lock" "${flags[@]}" --output "$dest/result.json"
