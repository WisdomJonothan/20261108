#!/usr/bin/env bash
set -euo pipefail
work=$1
panel="$work/transfer-reserve-242"
export PYTHONPATH="$work:scripts"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
py=.venv/bin/python
until [ -s "$panel/old-junior.json" ]; do sleep 5; done
if [ ! -s "$panel/warm-scan-other-input.json" ]; then
"$py" - "$panel/locked-local-vote/large-scan.json" "$panel/warm-scan-other-input.json" <<'PY'
from pathlib import Path
import json,sys
source,target=map(Path,sys.argv[1:])
rows=[r for r in json.loads(source.read_text())['queries'] if r['domain']!='history']
assert len(rows)==130
with target.open('x') as out: json.dump({'queries':rows},out,separators=(',',':'))
PY
fi
gpu=2
until [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 5; done
CUDA_VISIBLE_DEVICES=$gpu "$py" -u "$work/score_specialist_shortlists.py" --manifest "$panel/warm-scan-other-input.json" --data-root data/track1_tempo --model /dev/shm/reteco-yuanbao-0101299 --model-revision 0101299a7937a016848d8d55b092f6e31cfa312d --evidence-mode dispersed --clip-dispersed-outliers --batch-size 32 --checkpoint "$panel/warm-scan-other" --output "$panel/warm-scan-other.json"
for i in 0 1 2 3; do
    mkdir -p "$panel/locked-local-vote/scan-p$i"
    for cache in "$panel"/warm-scan-other/*.json; do
        ln -n "$cache" "$panel/locked-local-vote/scan-p$i/" 2>/dev/null || test -s "$panel/locked-local-vote/scan-p$i/$(basename "$cache")"
    done
done
echo 'Identical checkpoints available for the twelve non-History domains'
