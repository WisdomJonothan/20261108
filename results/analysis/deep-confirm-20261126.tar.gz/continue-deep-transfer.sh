#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
reserve=$4
phase=$5
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
p=.venv/bin/python
data=data/track1_tempo
select="$work/deep-held-admission.json"
case "$phase" in
confirm)
    wide="$study/confirmation60.json"
    reference="$study/confirmation-head.json"
    old_pointwise=("$study/confirm-first-p2.json")
    old_evidence=("$study"/confirm-reasoner-p?.json)
    transfer_flags=(--confirmation)
    ;;
reserve)
    wide="$reserve/wide.json"
    reference="$reserve/head.json"
    old_pointwise=("$reserve"/8b-p?.json)
    old_evidence=("$reserve"/reasoner-p?-part?.json)
    transfer_flags=(--confirmation --reserve-ids "$study/second-transfer-query-ids.json")
    ;;
*) exit 2 ;;
esac
while [ "$(find "$work" -maxdepth 1 -size +0c -name "deep-0p6b-$phase-p?.json" | wc -l)" -ne 4 ]; do sleep 10; done
test "$(sha256sum "$select" | cut -d' ' -f1)" = 98790b563afd63de035c1ba8ac11932327eb3e6992c4cf1bb33fa658c746c732
prefix="$work/deep-transfer-$phase"
"$p" -m retrieve_union_with_pointwise_scan pools --manifest "$work/deep-0p6b-$phase-manifest.json" --reference "$reference" --scores "$work"/deep-0p6b-"$phase"-p?.json --output "$prefix-union.json"
"$p" - "$select" "$prefix-union.json" "$prefix-pools.json" <<'PY'
from pathlib import Path
import json,sys
sel,full,new=map(Path,sys.argv[1:])
arm=json.loads(sel.read_text())['selected']
assert arm=='pointwise_depth200'
a=json.loads(full.read_text())
a['sources']=[arm]
for row in a['per_query']:
    row['offers']={arm:row['offers'][arm]}
with new.open('x') as out:
    json.dump(a,out,separators=(',',':'))
PY
"$p" -m replay_feedback_admission prepare --manifest "$wide" --pools "$prefix-pools.json" --output "$prefix-offers.json"
"$p" - "$prefix-offers.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1])
rows=json.loads(p.read_text())['queries']
for i in range(2):
    with p.with_stem(p.stem+f'-p{i}').open('x') as out:
        json.dump({'queries':rows[i::2]},out,separators=(',',':'))
PY
free=()
until [ "${#free[@]}" -ge 3 ]; do
    free=()
    for gpu in 0 1 2 3; do
        if [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then free+=("$gpu"); fi
    done
    if [ "${#free[@]}" -lt 3 ]; then sleep 10; fi
done
pids=()
CUDA_VISIBLE_DEVICES=${free[0]} "$p" -u "$work/score_specialist_shortlists.py" --manifest "$prefix-offers.json" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --checkpoint "$prefix-8b" --output "$prefix-8b.json" > "$prefix-8b.log" 2>&1 &
pids+=($!)
for i in 0 1; do
    CUDA_VISIBLE_DEVICES=${free[i+1]} PYTHONPATH="$stage:scripts" "$p" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$prefix-offers-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$prefix-quote-p$i" --output "$prefix-quote-p$i.json" > "$prefix-quote-p$i.log" 2>&1 &
    pids+=($!)
done
for pid in "${pids[@]}"; do wait "$pid"; done
"$p" -m replay_feedback_admission narrow --grade-all-offers --manifest "$prefix-offers.json" --pointwise "$prefix-8b.json" --output "$prefix-narrow.json"
"$p" -m replay_feedback_admission evaluate --manifest "$prefix-narrow.json" --reference "$reference" --data-root "$data" --old-pointwise "${old_pointwise[@]}" --new-pointwise "$prefix-8b.json" --old-evidence "${old_evidence[@]}" --new-evidence "$prefix"-quote-p?.json --selection "$select" "${transfer_flags[@]}" --output "$prefix-result.json"
