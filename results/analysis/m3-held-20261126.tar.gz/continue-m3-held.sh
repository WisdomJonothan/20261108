#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
population=$3
export PYTHONPATH="$work:$population/admission-study:$population:$stage:scripts"
py=.venv/bin/python
data=data/track1_tempo
manifest="$work/m3-held-score-manifest.json"
until [ "$(find "$work" -maxdepth 1 -size +0c -name 'm3-heldquote-p?.json' | wc -l)" = 4 ]; do sleep 5; done
pids=()
for gpu in 0 1 2 3; do
    until [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 5; done
    CUDA_VISIBLE_DEVICES=$gpu "$py" -u scripts/score_specialist_shortlists.py --manifest "$manifest" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --batch-size 6 --shards 4 --shard-index "$gpu" --checkpoint "$work/m3-held8b-p$gpu" --output "$work/m3-held8b-p$gpu.json" > "$work/m3-held8b-p$gpu.log" 2>&1 &
    pids+=($!)
done
for pid in "${pids[@]}"; do wait "$pid"; done
"$py" -m replay_feedback_admission narrow --grade-all-offers --manifest "$manifest" --pointwise "$work"/m3-held8b-p?.json --output "$work/m3-held-full-offers.json"
"$py" -m replay_feedback_admission evaluate --manifest "$work/m3-held-full-offers.json" --reference "$stage/evidence-consensus-head-replay-holdout.json" --data-root "$data" --old-pointwise "$stage"/pretrained-held-p?.json "$stage"/pretrained-extra-p?.json --new-pointwise "$work"/m3-held8b-p?.json --old-evidence "$stage"/evidence-reasoner-held-p?.json --new-evidence "$work"/m3-heldquote-p?.json --output "$work/m3-held-admission.json"
