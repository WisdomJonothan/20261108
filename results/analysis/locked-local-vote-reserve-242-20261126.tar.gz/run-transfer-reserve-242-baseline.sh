#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
retrieval=$4
panel="$work/transfer-reserve-242"
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
p=.venv/bin/python
data=data/track1_tempo
q8=/dev/shm/reteco-qwen3-reranker-8b-77d193c
q6=/dev/shm/reteco-yuanbao-0101299
pin8=77d193c791ed757ca307ee72715aa132723da912
pin6=0101299a7937a016848d8d55b092f6e31cfa312d
score() {
    local gpu=$1 input=$2 model=$3 pin=$4 mode=$5 batch=$6 prefix=$7
    shift 7
    until [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 8; done
    CUDA_VISIBLE_DEVICES=$gpu "$p" -u "$work/score_specialist_shortlists.py" --manifest "$input" --data-root "$data" --model "$model" --model-revision "$pin" --evidence-mode "$mode" --batch-size "$batch" --checkpoint "$prefix" --output "$prefix.json" "$@" > "$prefix.log" 2>&1
}
echo 'Rebuild the 242-question reference without opening its relevance judgments'
(
    score 0 "$panel/first30.json" models/Qwen3-Reranker-4B local-Qwen3-Reranker-4B temporal 12 "$panel/first-temporal"
    score 0 "$panel/wide60.json" "$q6" "$pin6" dispersed 32 "$panel/old-junior" --clip-dispersed-outliers
) &
a=$!
score 1 "$panel/first30.json" models/Qwen3-Reranker-4B local-Qwen3-Reranker-4B dispersed 12 "$panel/first-dispersed" --clip-dispersed-outliers &
b=$!
jobs=()
for i in 0 1; do
    score "$((2+i))" "$panel/wide60.json" "$q8" "$pin8" dispersed 6 "$panel/old-pointwise-p$i" --shards 2 --shard-index "$i" --clip-dispersed-outliers &
    jobs+=($!)
done
wait "$a"
wait "$b"
for pid in "${jobs[@]}"; do wait "$pid"; done
echo 'First stage ready on all 13 domains'
"$p" "$work/build_temporal_confirmation.py" repair --training-manifest /tmp/reteco/rerank_headroom_train_20261125.json --training-scores "$retrieval/score-train-temporal.json" "$retrieval/score-train-dispersed.json" --manifest "$panel/first30.json" --data-root "$data" --pointwise "$panel/first-temporal.json" "$panel/first-dispersed.json" --query-count 242 --output "$panel/repair.json"
PYTHONPATH="$stage:scripts" "$p" "$stage/eval_evidence_reasoner_clause.py" prepare --manifest "$panel/wide60.json" --repair "$panel/repair.json" --first "$panel"/old-pointwise-p?.json --second "$panel/old-junior.json" --per-tier 2 --output "$panel/shortlist.json"
"$p" - "$panel/shortlist.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]); rows=json.loads(p.read_text())['queries']
assert len(rows)==242 and all(len(r['docs'])==14 for r in rows)
for i in range(4):
    with p.with_stem(p.stem+f'-p{i}').open('x') as out:
        json.dump({'queries':rows[i::4]},out,separators=(',',':'))
PY
jobs=()
for i in 0 1 2 3; do
    (
        until [ "$(nvidia-smi -i "$i" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 8; done
        CUDA_VISIBLE_DEVICES=$i PYTHONPATH="$stage:scripts" "$p" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$panel/shortlist-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$panel/proof-p$i" --output "$panel/proof-p$i.json"
    ) > "$panel/proof-p$i.log" 2>&1 &
    jobs+=($!)
done
for pid in "${jobs[@]}"; do wait "$pid"; done
"$p" "$work/build_temporal_confirmation.py" consensus --wide "$panel/wide60.json" --repair "$panel/repair.json" --reasoner "$panel"/proof-p?.json --pointwise "$panel"/old-pointwise-p?.json --query-count 242 --output "$panel/consensus.json" --head-output "$panel/head.json"
echo 'Frozen reference rankings complete. No relevance judgments read for these topics.'
