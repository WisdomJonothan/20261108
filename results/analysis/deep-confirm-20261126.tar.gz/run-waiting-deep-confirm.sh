#!/usr/bin/env bash
set -euo pipefail
work=$1
while [ ! -e "$work/deep-0p6b-confirm-p0.json" ]; do
    for gpu in 0 1 2 3; do
        if [ "$gpu" -ne 0 ] && [ ! -s "$work/deep-0p6b-confirm-p$gpu.json" ]; then continue; fi
        if [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -ge 512 ]; then continue; fi
        echo "Starting confirmation shard 0 on GPU $gpu"
        CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python -u "$work/score_specialist_shortlists.py" --manifest "$work/deep-0p6b-confirm-manifest.json" --data-root data/track1_tempo --model /dev/shm/reteco-yuanbao-0101299 --model-revision 0101299a7937a016848d8d55b092f6e31cfa312d --evidence-mode dispersed --clip-dispersed-outliers --batch-size 32 --shards 4 --shard-index 0 --checkpoint "$work/deep-0p6b-confirm-p0" --output "$work/deep-0p6b-confirm-p0.json"
        exit 0
    done
    sleep 10
done
