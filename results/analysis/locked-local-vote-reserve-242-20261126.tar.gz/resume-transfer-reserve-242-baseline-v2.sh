#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
retrieval=$4
orig="$work/run-transfer-reserve-242-baseline.sh"
panel="$work/transfer-reserve-242"
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
p=.venv/bin/python
data=data/track1_tempo
q6=/dev/shm/reteco-yuanbao-0101299
pin6=0101299a7937a016848d8d55b092f6e31cfa312d
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
source <(sed -n '/^score() {/,/^}/p' "$orig")
pick_cards() {
    local minimum=$1 exclude=${2:-none}
    local i
    while :; do
        free=()
        for i in 0 1 2 3; do
            [ "$i" = "$exclude" ] && continue
            if [ "$(nvidia-smi -i "$i" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then free+=("$i"); fi
        done
        if [ "${#free[@]}" -ge "$minimum" ]; then return; fi
        sleep 8
    done
}
echo 'Wait for started score shards, and move only the unstarted temporal score to an available device'
pick_cards 1
temporal_gpu=${free[0]}
score "$temporal_gpu" "$panel/first30.json" models/Qwen3-Reranker-4B local-Qwen3-Reranker-4B temporal 12 "$panel/first-temporal" &
a=$!
pick_cards 1 "$temporal_gpu"
score "${free[0]}" "$panel/wide60.json" "$q6" "$pin6" dispersed 32 "$panel/old-junior" --clip-dispersed-outliers &
b=$!
wait "$a"
wait "$b"
until [ -s "$panel/first-dispersed.json" ] && [ -s "$panel/old-pointwise-p0.json" ] && [ -s "$panel/old-pointwise-p1.json" ]; do sleep 8; done
echo 'First stage ready on all 13 domains'
"$p" "$work/build_temporal_confirmation.py" repair --training-manifest /tmp/reteco/rerank_headroom_train_20261125.json --training-scores "$retrieval/score-train-temporal.json" "$retrieval/score-train-dispersed.json" --manifest "$panel/first30.json" --data-root "$data" --pointwise "$panel/first-temporal.json" "$panel/first-dispersed.json" --query-count 242 --output "$panel/repair.json"
PYTHONPATH="$stage:scripts" "$p" "$stage/eval_evidence_reasoner_clause.py" prepare --manifest "$panel/wide60.json" --repair "$panel/repair.json" --first "$panel"/old-pointwise-p?.json --second "$panel/old-junior.json" --per-tier 2 --output "$panel/shortlist.json"
pick_cards 2
"$p" - "$panel/shortlist.json" "${#free[@]}" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]); n=int(sys.argv[2]); rows=json.loads(p.read_text())['queries']
assert len(rows)==242 and all(len(r['docs'])==14 for r in rows)
for i in range(n):
    with p.with_stem(p.stem+f'-p{i}').open('x') as out:
        json.dump({'queries':rows[i::n]},out,separators=(',',':'))
PY
jobs=()
for i in "${!free[@]}"; do
    CUDA_VISIBLE_DEVICES="${free[i]}" PYTHONPATH="$stage:scripts" "$p" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$panel/shortlist-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$panel/proof-p$i" --output "$panel/proof-p$i.json" > "$panel/proof-p$i.log" 2>&1 &
    jobs+=("$!")
done
for pid in "${jobs[@]}"; do wait "$pid"; done
"$p" "$work/build_temporal_confirmation.py" consensus --wide "$panel/wide60.json" --repair "$panel/repair.json" --reasoner "$panel"/proof-p?.json --pointwise "$panel"/old-pointwise-p?.json --query-count 242 --output "$panel/consensus.json" --head-output "$panel/head.json"
echo 'Frozen reference rankings complete. No relevance judgments read for these topics.'
