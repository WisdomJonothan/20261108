#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
reserve=$4
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
p=.venv/bin/python
data=data/track1_tempo
select="$work/wide-vote-held-calibrated.json"
fixed=d5265d8da075a84914e41489d723114254f45c36e2b7dca783b249517bb73fd6
test "$(sha256sum "$select" | cut -d' ' -f1)" = "$fixed"
"$p" - "$work/wide-vote-confirm-result.json" <<'PY'
import sys,json
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text())
assert r['selected']=='original_candidate_scale'
assert r['confirmation']['selected']['change']['point']>0 and r['selected_minimum_leave_one_domain_out']>0
print('Fixed rule met both confirmation gates',flush=True)
PY
until [ "$(find "$work" -maxdepth 1 -name 'deep-0p6b-reserve-p?.json' -size +0c | wc -l)" -eq 4 ]; do sleep 10; done
"$p" -m replay_wide_pointwise_vote prepare --manifest "$work/deep-0p6b-reserve-manifest.json" --reference "$reserve/head.json" --initial-scan "$work"/deep-0p6b-reserve-p?.json --pointwise "$reserve"/8b-p?.json --output "$work/wide-vote-reserve-scopes.json" --missing-manifest "$work/wide-vote-reserve-missing.json"
remaining=()
running=()
for i in 0 1 2 3; do
    if [ "$(nvidia-smi -i "$i" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then
        CUDA_VISIBLE_DEVICES=$i "$p" -u "$work/score_specialist_shortlists.py" --manifest "$work/wide-vote-reserve-missing.json" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --shards 4 --shard-index "$i" --checkpoint "$work/wide-vote-reserve8b-p$i" --output "$work/wide-vote-reserve8b-p$i.json" > "$work/wide-vote-reserve8b-p$i.log" 2>&1 &
        running+=($!)
    else
        remaining+=("$i")
    fi
done
for pid in "${running[@]}"; do wait "$pid"; done
for i in "${remaining[@]}"; do
    while ! nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | awk '$1<512 {x=1} END{exit !x}'; do sleep 8; done
    gpu=$(nvidia-smi --query-gpu=index,memory.used --format=csv,noheader,nounits | awk -F, '$2<512 {print $1; exit}')
    CUDA_VISIBLE_DEVICES=$gpu "$p" -u "$work/score_specialist_shortlists.py" --manifest "$work/wide-vote-reserve-missing.json" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --shards 4 --shard-index "$i" --checkpoint "$work/wide-vote-reserve8b-p$i" --output "$work/wide-vote-reserve8b-p$i.json" > "$work/wide-vote-reserve8b-p$i.log" 2>&1
done
"$p" -m replay_wide_pointwise_vote evaluate --retain-position-prior --manifest "$work/wide-vote-reserve-scopes.json" --consensus "$reserve/consensus.json" --reference "$reserve/head.json" --data-root "$data" --pointwise "$reserve"/8b-p?.json "$work"/wide-vote-reserve8b-p?.json --evidence "$reserve"/reasoner-p?-part?.json --selection "$select" --confirmation --reserve-ids "$study/second-transfer-query-ids.json" --output "$work/wide-vote-reserve-result.json"
