#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
confirm=$3
export PYTHONPATH="$work:$confirm/admission-study:$confirm:$stage:scripts"
data=data/track1_tempo
python=.venv/bin/python
selection="$work/native-held-full-admission.json"
while [ "$(find "$work" -maxdepth 1 -size +0c -name 'native-wide-confirm-p?.json' | wc -l)" -ne 4 ]; do sleep 10; done
test "$(sha256sum "$selection" | cut -d' ' -f1)" = 8fd86f1418d8ae1f0b6238e4c1f2a98f2e992c8c65438207b82296ca26963881
"$python" -m retrieve_union_with_reasoning_encoder combine --shards "$work"/native-wide-confirm-p?.json --output "$work/native-wide-confirm-union.json"
"$python" - "$selection" "$work/native-wide-confirm-union.json" "$work/native-wide-confirm-fixed.json" <<'PY'
import json,sys
from pathlib import Path
selector, union, output=map(Path,sys.argv[1:])
policy=json.loads(selector.read_text())['selected']
assert policy=='diver'
pool=json.loads(union.read_text())
pool['sources']=[policy]
for row in pool['per_query']:
    row['offers']={policy:row['offers'][policy]}
with output.open('x') as handle:
    json.dump(pool,handle,separators=(',',':'))
PY
"$python" -m replay_feedback_admission prepare --manifest "$confirm/confirmation60.json" --pools "$work/native-wide-confirm-fixed.json" --output "$work/native-confirm-score-manifest.json"
"$python" - "$work/native-confirm-score-manifest.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1])
rows=json.loads(p.read_text())['queries']
for i in range(2):
    with p.with_stem(p.stem+f'-p{i}').open('x') as handle:
        json.dump({'queries':rows[i::2]},handle,separators=(',',':'))
PY
pids=()
for i in 0 1; do
    gpu=$((i+2))
    CUDA_VISIBLE_DEVICES=$gpu PYTHONPATH="$stage:scripts" "$python" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$work/native-confirm-score-manifest-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$work/native-confirmquote-p$i" --output "$work/native-confirmquote-p$i.json" > "$work/native-confirmquote-p$i.log" 2>&1 &
    pids+=($!)
    CUDA_VISIBLE_DEVICES=$i "$python" -u scripts/score_specialist_shortlists.py --manifest "$work/native-confirm-score-manifest.json" --data-root "$data" --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --batch-size 6 --shards 2 --shard-index "$i" --checkpoint "$work/native-confirm8b-p$i" --output "$work/native-confirm8b-p$i.json" > "$work/native-confirm8b-p$i.log" 2>&1 &
    pids+=($!)
done
for pid in "${pids[@]}"; do wait "$pid"; done
"$python" -m replay_feedback_admission narrow --grade-all-offers --manifest "$work/native-confirm-score-manifest.json" --pointwise "$work"/native-confirm8b-p?.json --output "$work/native-confirm-full-offers.json"
"$python" -m replay_feedback_admission evaluate --manifest "$work/native-confirm-full-offers.json" --reference "$confirm/confirmation-head.json" --data-root "$data" --old-pointwise "$confirm/confirm-first-p2.json" --new-pointwise "$work"/native-confirm8b-p?.json --old-evidence "$confirm"/confirm-reasoner-p?.json --new-evidence "$work"/native-confirmquote-p?.json --selection "$selection" --confirmation --output "$work/native-confirm-admission.json"
