#!/usr/bin/env bash
set -euo pipefail
work=$1
phase=$2
until [ -s "$work/wide-vote-$phase"8b-p0.json ]; do
    for gpu in 0 1 2 3; do
        if [ "$gpu" -ne 0 ] && [ ! -s "$work/wide-vote-$phase"8b-p"$gpu".json ]; then continue; fi
        if [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -ge 512 ]; then continue; fi
        echo "Starting 8B shard 0 on available GPU $gpu"
        CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python -u "$work/score_specialist_shortlists.py" --manifest "$work/wide-vote-$phase-missing.json" --data-root data/track1_tempo --model /dev/shm/reteco-qwen3-reranker-8b-77d193c --model-revision 77d193c791ed757ca307ee72715aa132723da912 --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --shards 4 --shard-index 0 --checkpoint "$work/wide-vote-$phase"8b-p0 --output "$work/wide-vote-$phase"8b-p0.json
        exit 0
    done
    sleep 10
done
