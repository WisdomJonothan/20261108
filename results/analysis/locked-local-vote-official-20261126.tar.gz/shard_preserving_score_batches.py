"""Balance inference work without changing any domain's ordered prompt batches."""
import argparse
from collections import Counter, defaultdict
from itertools import accumulate
import json
from math import ceil
from pathlib import Path


def batches(rows, size):
    prompts = defaultdict(list)
    for row in rows:
        prompts[row['domain']].extend((row['qid'], doc) for doc in row['docs'])
    return Counter((domain, tuple(items[start:start+size]))
                   for domain, items in prompts.items() for start in range(0, len(items), size))


def divide(rows, shards, size):
    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[row['domain']].append((i, len(row['docs'])))
    target = sum(length for group in groups.values() for _, length in group)/shards
    chunks = []
    for group in groups.values():
        cumulative = list(accumulate(length for _, length in group))
        amount = cumulative[-1]
        eligible = [(rank + 1, cost) for rank, cost in enumerate(cumulative[:-1]) if cost % size == 0]
        divisions = min(ceil(amount/target), len(eligible)+1)
        boundaries = sorted({min(eligible, key=lambda b: abs(b[1]-amount*i/divisions))[0]
                             for i in range(1, divisions)})
        for start, end in zip([0,*boundaries], [*boundaries,len(group)], strict=True):
            chunks.append(group[start:end])
    assigned = [[] for _ in range(shards)]
    totals = [0]*shards
    for chunk in sorted(chunks, key=lambda c: -sum(n for _, n in c)):
        slot = min(range(shards), key=totals.__getitem__)
        assigned[slot].extend(i for i,_ in chunk)
        totals[slot] += sum(n for _,n in chunk)
    result = [[rows[i] for i in sorted(indices)] for indices in assigned]
    if any(not seq for seq in result) or sum(map(len,result)) != len(rows):
        raise ValueError('Expected each query in one non-empty shard')
    reconstructed = sum((batches(seq,size) for seq in result), Counter())
    if reconstructed != batches(rows,size):
        raise ValueError('The exact prompt batches must be preserved across scoring shards')
    return result, totals


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('prefix',type=Path)
    parser.add_argument('shards',type=int)
    parser.add_argument('batch',type=int)
    args=parser.parse_args()
    rows=json.loads(args.input.read_text())['queries']
    shards,totals=divide(rows,args.shards,args.batch)
    for i,shard in enumerate(shards):
        with args.prefix.with_name(args.prefix.name+f'-input-p{i}.json').open('x') as handle:
            json.dump({'queries':shard},handle,separators=(',',':'))
    print('Identical prompt batches across shards; prompt counts',totals,flush=True)


if __name__=='__main__':
    main()
