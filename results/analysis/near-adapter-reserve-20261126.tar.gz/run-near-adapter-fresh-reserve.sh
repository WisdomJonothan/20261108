#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
retrieval=$4
fresh="$work/adapter-reserve-109"
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
export TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
p=.venv/bin/python
data=data/track1_tempo
model8=/dev/shm/reteco-qwen3-reranker-8b-77d193c
pin8=77d193c791ed757ca307ee72715aa132723da912
junior=/dev/shm/reteco-yuanbao-0101299
pin06=0101299a7937a016848d8d55b092f6e31cfa312d
fits="$work/wide-adapter-768-control-retry/epoch-1.pt"
locked="$work/near-adapter-held-result.json"
test "$(sha256sum "$locked"|cut -d' ' -f1)" = 4148dec80019866bb1d76517a48c08b25a07ba05699ff5419500fd484c721349
test "$(sha256sum "$fits"|cut -d' ' -f1)" = 116eabc2563cf440752cab9d54225a0bd1e291853d95f2326bb4ca1195068d2a
"$p" - "$work/near-adapter-confirm-result.json" <<'PY'
import json,sys
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text())
assert r['selected']=='near_positive_adapter'
assert r['confirmation']['selected']['change']['point']>0 and r['selected_minimum_leave_one_domain_out']>0
print('Fixed near-positive candidate passed both 155-question gates',flush=True)
PY

score() {
    local gpu=$1 manifest=$2 model=$3 revision=$4 width=$5 batch=$6 prefix=$7
    shift 7
    until [ "$(nvidia-smi -i "$gpu" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 8; done
    CUDA_VISIBLE_DEVICES=$gpu "$p" -u "$work/score_specialist_shortlists.py" --manifest "$manifest" --data-root "$data"         --model "$model" --model-revision "$revision" --evidence-mode "$width" --batch-size "$batch"         --checkpoint "$prefix" --output "$prefix.json" "$@" > "$prefix.log" 2>&1
}
model4=models/Qwen3-Reranker-4B
score 0 "$fresh/first30.json" "$model4" local-Qwen3-Reranker-4B temporal 12 "$fresh/first-temporal" &
jobs=($!)
score 1 "$fresh/first30.json" "$model4" local-Qwen3-Reranker-4B dispersed 12 "$fresh/first-dispersed" --clip-dispersed-outliers &
jobs+=($!)
score 2 "$fresh/wide60.json" "$model8" "$pin8" dispersed 6 "$fresh/old-pointwise" --clip-dispersed-outliers &
jobs+=($!)
score 3 "$fresh/wide60.json" "$junior" "$pin06" dispersed 24 "$fresh/old-junior" --clip-dispersed-outliers &
jobs+=($!)
for pid in "${jobs[@]}"; do wait "$pid"; done
echo 'Reconstructing the reference ranking' 
"$p" "$stage/build_temporal_confirmation.py" repair --training-manifest /tmp/reteco/rerank_headroom_train_20261125.json --training-scores "$retrieval/score-train-temporal.json" "$retrieval/score-train-dispersed.json" --manifest "$fresh/first30.json" --data-root "$data" --pointwise "$fresh/first-temporal.json" "$fresh/first-dispersed.json" --query-count 109 --output "$fresh/repair.json"
PYTHONPATH="$stage:scripts" "$p" "$stage/eval_evidence_reasoner_clause.py" prepare --manifest "$fresh/wide60.json" --repair "$fresh/repair.json" --first "$fresh/old-pointwise.json" --second "$fresh/old-junior.json" --per-tier 2 --output "$fresh/shortlist.json"
"$p" - "$fresh/shortlist.json" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]); rows=json.loads(p.read_text())['queries']
assert len(rows)==109 and all(len(r['docs'])==14 for r in rows)
for i in range(2):
    with p.with_stem(p.stem+f'-p{i}').open('x') as out:
        json.dump({'queries':rows[i::2]},out,separators=(',',':'))
PY
jobs=()
for i in 0 1; do
    (
        until [ "$(nvidia-smi -i "$i" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; do sleep 8; done
        CUDA_VISIBLE_DEVICES=$i PYTHONPATH="$stage:scripts" "$p" -u "$stage/eval_evidence_reasoner_clause.py" score --manifest "$fresh/shortlist-p$i.json" --data-root "$data" --model models/Qwen3-4B-Instruct-2507 --batch-size 8 --max-new-tokens 80 --checkpoint "$fresh/old-evidence-p$i" --output "$fresh/old-evidence-p$i.json"
    ) > "$fresh/old-evidence-p$i.log" 2>&1 &
    jobs+=($!)
    score "$((2+i))" "$fresh/large-scan.json" "$junior" "$pin06" dispersed 32 "$fresh/scan-p$i" --clip-dispersed-outliers --shards 2 --shard-index "$i" &
    jobs+=($!)
done
for pid in "${jobs[@]}"; do wait "$pid"; done
"$p" "$stage/build_temporal_confirmation.py" consensus --wide "$fresh/wide60.json" --repair "$fresh/repair.json" --reasoner "$fresh"/old-evidence-p?.json --pointwise "$fresh/old-pointwise.json" --query-count 109 --output "$fresh/consensus.json" --head-output "$fresh/head.json"
"$p" -m replay_wide_pointwise_vote prepare --manifest "$fresh/large-scan.json" --reference "$fresh/head.json" --initial-scan "$fresh"/scan-p?.json --pointwise "$fresh/old-pointwise.json" --output "$fresh/scopes.json" --missing-manifest "$fresh/missing.json"
"$p" -m evaluate_wide_evidence_adapters prepare --manifest "$fresh/wide60.json" --scopes "$fresh/scopes.json" --output "$fresh/hybrid30.json"
jobs=()
for i in 0 1; do
    score "$i" "$fresh/missing.json" "$model8" "$pin8" dispersed 6 "$fresh/extra8b-p$i" --clip-dispersed-outliers --shards 2 --shard-index "$i" &
    jobs+=($!)
    score "$((2+i))" "$fresh/hybrid30.json" "$model8" "$pin8" dispersed 6 "$fresh/adapter-p$i" --clip-dispersed-outliers --shards 2 --shard-index "$i" --adapter "$fits" &
    jobs+=($!)
done
for pid in "${jobs[@]}"; do wait "$pid"; done
"$p" -m evaluate_wide_evidence_adapters evaluate --screen-near-control --manifest "$fresh/hybrid30.json" --reference "$fresh/head.json" --consensus "$fresh/consensus.json" --data-root "$data" --base "$fresh/old-pointwise.json" "$fresh"/extra8b-p?.json --near "$fresh"/adapter-p?.json --evidence "$fresh"/old-evidence-p?.json --selection "$locked" --confirmation --reserve-ids "$work/wide-adapter-input-768/reserve-ids.json" --output "$fresh/near-adapter-reserve-result.json"
