#!/usr/bin/env bash
set -euo pipefail
work=$1
stage=$2
study=$3
export PYTHONPATH="$work:$study/admission-study:$study:$stage:scripts"
p=.venv/bin/python
mode=wide-adapter-held
manifest="$work/$mode"30.json
dataset=data/track1_tempo
model=/dev/shm/reteco-qwen3-reranker-8b-77d193c
pin=77d193c791ed757ca307ee72715aa132723da912
test -s "$manifest"
until grep -q 'Training 342 groups' "$work/wide-adapter-train-control-retry.log"; do sleep 8; done
declare -A assigned=()
children=()
for spec in wide:0 wide:1 control:0 control:1; do
    arm=${spec%:*}
    slot=${spec#*:}
    folder="$work/wide-adapter-768-$arm"
    if [ "$arm" = control ]; then folder="$folder-retry"; fi
    checkpoint="$folder/epoch-1.pt"
    until [ -s "$checkpoint" ]; do sleep 8; done
    gpu=''
    while [ -z "$gpu" ]; do
        for want in 0 1 2 3; do
            old=${assigned[$want]:-}
            if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then continue; fi
            if [ "$(nvidia-smi -i "$want" --query-gpu=memory.used --format=csv,noheader,nounits)" -lt 512 ]; then gpu=$want; break; fi
        done
        if [ -z "$gpu" ]; then sleep 8; fi
    done
    prefix="$work/$mode-$arm-p$slot"
    echo "Starting $arm shard $slot on GPU $gpu" 
    CUDA_VISIBLE_DEVICES=$gpu "$p" -u "$work/score_specialist_shortlists.py" --manifest "$manifest" --data-root "$dataset" --model "$model" --model-revision "$pin" --adapter "$checkpoint" --evidence-mode dispersed --clip-dispersed-outliers --batch-size 6 --shards 2 --shard-index "$slot" --checkpoint "$prefix" --output "$prefix.json" > "$prefix.log" 2>&1 &
    assigned[$gpu]=$!
    children+=($!)
done
for pid in "${children[@]}"; do wait "$pid"; done
"$p" -m evaluate_wide_evidence_adapters evaluate --manifest "$manifest" --reference "$stage/evidence-consensus-head-replay-holdout.json" --consensus "$stage/evidence-consensus-extension-holdout.json" --data-root "$dataset" --base "$stage"/pretrained-held-p?.json "$stage"/pretrained-extra-p?.json "$work"/deep-held8b-p?.json "$work"/wide-vote-held8b-p?.json --near "$work"/"$mode"-control-p?.json --wide "$work"/"$mode"-wide-p?.json --evidence "$stage"/evidence-reasoner-held-p?.json --output "$work/$mode-result.json"
